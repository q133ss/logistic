<?php $__env->startSection('title', 'Панель администратора'); ?>
<?php $__env->startSection('content'); ?>
    <section class="service">
        <div class="containers">
            <div class="service__w">
                <?php echo $__env->make('admin.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <ul class="service__info">
                    <li class="service__info-h">
                        <div class="service__info-title">Статус</div>
                        <div class="service__info-tp">
                            <h5>Компания</h5>
                            <p>номер</p>
                        </div>
                        <div class="service__info-st">Направление</div>
                        <div class="service__info-fn">Контактное лицо</div>
                        <div class="service__info-js">Действия</div>
                    </li>
                    <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="service__info-e">
                        <div class="service__info-a service__info-a__red service__info-a__yellow service__info-a__green">Новая</div>
                        <div class="service__info-path">
                            <h5>«<?php echo e($company->company); ?>»</h5>
                            <p><?php echo e($company->id); ?></p>
                        </div>
                        <div class="service__info-start">
                            <p>Караганда</p>
                        </div>
                        <div class="service__info-finally">
                            <h5><?php echo e($company->contact_face); ?> </h5>
                            <p></p>
                        </div>
                        <div class="service__info-just">
                            <button class="service__info-mail" onclick="location.href='mailto:<?php echo e($company->email); ?>'"> <img src="/assets/svg/service/mail.svg" alt="icons"></button>
                            <button class="service__info-phone" onclick="location.href='tel:<?php echo e($company->phone); ?>'"> <img src="/assets/svg/service/phone.svg" alt="icons"></button>
                            <button class="service__info-more"><img src="/assets/svg/service/more.svg" alt="icons">
                                <ul class="selectOne display-n">
                                    <li class="selectOne__i selectOne__i-ready" onclick="location.href='/admin/accept/<?php echo e($company->id); ?>'">Одобрить компанию</li>
                                    <li class="selectOne__i selectOne__i-delete" onclick="$('#delete_<?php echo e($company->id); ?>').submit()">Удалить компанию</li>
                                    <li class="selectOne__i selectOne__i-info">Информация о компании</li>
                                </ul>
                            </button>
                            <button class="service__info-add">  <img src="/assets/svg/service/drop.svg" alt="icons"></button>
                        </div>
                    </li>
                        <form action="<?php echo e(route('admin.delete', $company->id)); ?>" id="delete_<?php echo e($company->id); ?>" style="display: none" method="POST">
                            <?php echo method_field('DELETE'); ?>
                            <?php echo csrf_field(); ?>
                        </form>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\OpenServer\domains\logistic\resources\views/admin/index.blade.php ENDPATH**/ ?>