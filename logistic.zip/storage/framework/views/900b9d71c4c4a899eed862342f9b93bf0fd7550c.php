<?php $__env->startSection('title', 'Заказы'); ?>
<?php $__env->startSection('content'); ?>
    <section class="service">
        <div class="containers">
            <div class="service__w">
                <?php echo $__env->make('admin.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <ul class="service__list">
                    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="service__list-e">
                            <div class="service__checkbox">
                                <input class="service__checkbox__input display-n" type="checkbox" id="checkbox_5">
                                <label class="service__checkbox__label display-n" for="checkbox_5"></label>
                            </div>
                            <div class="service__list-path">
                                <h5><?php echo e($order->name); ?></h5>
                                <p></p>
                            </div>
                            <div class="service__list-type">
                                <h5><?php echo e($order->phone); ?></h5>
                                <p></p>
                            </div>
                            <div class="service__list-start">
                                <p><?php echo e($order->get_waypoint->get_departure_city->name); ?></p>
                            </div>
                            <div class="service__list-finally">
                                <p><?php echo e($order->get_waypoint->get_arrival_city_id->name); ?></p>
                            </div>
                            <div class="service__list-just">
                                <button class="service__list-show" title="Данные о компании" onclick="get_company_data('<?php echo e($order->id); ?>')"> <img src="/assets/svg/service/eye.svg" alt="icons"></button>
                                <button class="service__list-more" title="Действия" onclick="get_waypoint_status('2222')"> <img src="/assets/svg/service/more.svg" alt="icons"></button>
                                <button class="service__list-users company__list-users" title="Данные о пользователе" onclick="get_user_data('<?php echo e($order->id); ?>')">
                                    <img src="/assets/svg/service/users.svg" alt="icons">
                                </button>





                                <button class="service__list-add" type="submit">  <img src="/assets/svg/service/drop.svg" alt="icons"></button>
                            </div>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <div class="info_car display-n">
        <div class="info_car__w">
            <button class="info_car__c"> <img src="/assets/svg/model/close.svg" alt="icons"></button>
            <ul class="info_car__b">
                <li class="info_car__i">
                    <div class="info_car__t">Компания</div>
                    <div class="info_car__e">
                        <h5>Название:</h5>
                        <p id="comp_title">Ромашка</p>
                    </div>

                    <div class="info_car__e">
                        <h5>Контактное лицо</h5>
                        <p id="comp_face">Алексей</p>
                    </div>

                    <div class="info_car__e">
                        <h5>Телефон</h5>
                        <p id="comp_phone">
                            89999
                        </p>
                    </div>
                </li>
                <li class="info_car__i">
                    <div class="info_car__t">Машина</div>
                    <div class="info_car__e">
                        <h5>Дата оправления:</h5>
                        <p id="date_of_comp_dep">25.06.2022</p>
                    </div>
                    <div class="info_car__e">
                        <h5>Время в пути:</h5>
                        <p id="time_on_tr_compavel">2 дня</p>
                    </div>
                    <div class="info_car__e">
                        <h5>Дата прибытия:</h5>
                        <p id="date_of_comp_arr">27.06.2022</p>
                    </div>
                </li>
                <li class="info_car__i">
                    <div class="info_car__t">Данные по грузу</div>
                    <div class="info_car__e">
                        <h5>Доступный вес:</h5>
                        <p id="data_of_av_weight"> кг</p>
                    </div>
                    <div class="info_car__e">
                        <h5>Доступный объем:</h5>
                        <p id="data_of_av_size">20 м.куб</p>
                    </div>
                    <div class="info_car__e">
                        <h5>Кол-во упаковок:</h5>
                        <p id="data_of_comp_qty">25 шт.</p>
                    </div>
                </li>
            </ul>
        </div>
    </div>

    <script>
        function get_company_data(waypoint_id){
            //Данные о компании
            $.get( "/api/get-waypoint-company/"+waypoint_id, function( data ) {
                let company = data.data;

                $('#comp_title').text(company.company);
                $('#comp_face').text(company.contact_face);
                $('#comp_phone').text(company.phone);
            });

            //Данные о маршруте
            $.get( "/api/get-waypoint-data-from-order/"+waypoint_id, function( data ) {
                let waypoint = data.data;

                $('#date_of_comp_dep').text(waypoint.departure_date);
                $('#time_on_comp_travel').text(waypoint.travel_time);
                $('#date_of_comp_arr').text(waypoint.arrival_date);
                $('#data_of_av_weight').text(waypoint.available_weight);
                $('#data_of_av_size').text(waypoint.available_size);
                $('#data_of_comp_qty').text(waypoint.packages_qty);
            });
            $('.info_car').removeClass('display-n');
            $("body").css("overflow","hidden");
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\OpenServer\domains\logistic\resources\views/admin/orders.blade.php ENDPATH**/ ?>