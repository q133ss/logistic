<?php $__env->startSection('title', 'Компания'); ?>
<?php $__env->startSection('content'); ?>
    <section class="company">
        <div class="containers">
            <div class="company__w">
                <?php echo $__env->make('company.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <form action="<?php echo e(route('company.create.car')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                <div class="company__search">
                    <div class="company__search-i">Для транспортной компании</div>
                    <div class="company__search-t">Добавить свободный транспорт</div>
                    <div class="company__search-b">
                        <div class="company__search-type">
                            <div class="company__search-h">
                                <p>Добавить транстпорт</p><img src="/assets/svg/index/help.svg" alt="icons">
                            </div>
                            <?php if($errors->count() != 0): ?>
                                <h5 style="color:red">Заполните все необходимые поля</h5>
                            <?php endif; ?>
                            <select required class="c_select" id="track_i" name="type" style="display: none">
                                <option>На чем будем везти</option>
                                <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($type->id); ?>"><?php echo e($type->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="company__search-type"></div>
                        <div class="company__search-type">
                            <div class="company__search-h">
                                <p>Откуда</p><img src="/assets/svg/index/help.svg" alt="icons">
                            </div>
                            <select required class="c_select" id="map_i" name="departure_city_id" style="display: none">
                                <option>Город номер 1</option>
                                <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($city->id); ?>"><?php echo e($city->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="company__search-type">
                            <div class="company__search-h">
                                <p>Куда</p><img src="/assets/svg/index/help.svg" alt="icons">
                            </div>
                            <select required class="c_select" id="map_i" name="arrival_city_id" style="display: none">
                                <option>Город номер 2</option>
                                <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($city->id); ?>"><?php echo e($city->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <input type="hidden" name="user_id" value="<?php echo e(Auth()->user()->id); ?>">
                    <div class="company__search-g">
                        <label class="company__search-e label" for="company__one">
                            <div class="company__search-text">
                                <p>Объем, м.куб </p><img src="/assets/svg/company/help.svg" alt="icons">
                            </div>
                            <input required type="text" name="size" id="company__one" placeholder="24 м.куб">
                        </label>
                        <label class="company__search-e label" for="company__two">
                            <div class="company__search-text">
                                <p>Грузоподъемность, кг</p><img src="/assets/svg/company/help.svg" alt="icons">
                            </div>
                            <input required type="text" name="weight" id="company__two" placeholder="500 кг">
                        </label>
                        <label class="company__search-e label" for="company__three">
                            <div class="company__search-text">
                                <p>Дата загрузки</p><img src="/assets/svg/company/help.svg" alt="icons">
                            </div>
                            <input required type="text" name="departure_date" id="company__three" placeholder="Дата загрузки">
                        </label>
                    </div>
                    <div class="company__search-g">
                        <label class="company__search-e label" for="company__three">
                            <div class="company__search-text">
                                <p>Номер машины</p><img src="/assets/svg/company/help.svg" alt="icons">
                            </div>
                            <input required type="text" name="car_number" id="company__three" placeholder="001 ААА 17">
                        </label>
                    </div>
                    <button class="company__search-rsl" type="submit">
                        <p>Добавить транспорт</p><img src="/assets/svg/company/chevron-right.svg" alt="icons"></button>
                </div>
                </form>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\OpenServer\domains\logistic\resources\views/company/index.blade.php ENDPATH**/ ?>