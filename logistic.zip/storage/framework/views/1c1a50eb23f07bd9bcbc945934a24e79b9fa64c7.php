<div class="notif display-n">
    <div class="notif__h">
        <div class="notif__h-t">Уведомления</div>
        <button class="notif__h-c"> <img src="/assets/svg/notif/close.svg" alt="icons"></button>
    </div>
    <ul class="notif__l">
        <?php $__currentLoopData = Auth()->user()->get_notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li class="notif__l-i"> <img src="/assets/svg/notif/car.svg" alt="icons">
            <div class="notif__l-t">
                <p><?php echo $notification->text; ?></p><span>5 минут назад</span>
            </div>
            <div class="notif__l-s"> </div>
        </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
<?php /**PATH E:\OpenServer\domains\logistic\resources\views/includes/notification.blade.php ENDPATH**/ ?>