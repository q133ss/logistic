<?php $__env->startSection('title', 'Поиск траспорта'); ?>
<?php $__env->startSection('content'); ?>
    <section class="carrier">
        <div class="containers">
            <div class="carrier__w">
                <?php echo $__env->make('client.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="carrier__car">
                    <p class="carrier__car-i">Поиск транспорта</p>
                    <h3 class="carrier__car-t">Мы нашли для вас <br>транспорт:<span><?php echo e($waypoints->count()); ?> фуры</span></h3>
                    <ul class="carrier__car-l">
                        <span class="service__info-a service__info-a__red service__info-a__yellow display-n" id="chose_transport">Выберите транспорт</span>
                        <span class="service__info-a service__info-a__red service__info-a__yellow display-n" id="name_error">Введите имя</span>
                        <span class="service__info-a service__info-a__red service__info-a__yellow display-n" id="phone_error">Введите телефон</span>
                        <?php $__currentLoopData = $waypoints; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $waypoint): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="carrier__car-e"><img class="carrier__car-icon" src="/assets/svg/carrier/car.svg" alt="icons">
                            <div class="carrier__car-w">
                                <div class="carrier__car-text">
                                    <p>Заполненность машины</p><span><?php echo e($waypoint->number); ?>%</span>
                                </div>
                                <div class="carrier__car-p" data-progress="<?php echo e($waypoint->number); ?>%">
                                    <div class="carrier__car-bar"></div>
                                </div>
                                <div class="carrier__car-info">Доступно для загрузки</div>
                                <div class="carrier__car-a">
                                    <h5>По весу:</h5>
                                    <p><?php echo e($waypoint->available_weight); ?></p>
                                </div>
                                <div class="carrier__car-a">
                                    <h5>По объему:</h5>
                                    <p><?php echo e($waypoint->available_size); ?></p>
                                </div>
                                <button class="carrier__car-trns chose__car" data-id="<?php echo e($waypoint->id); ?>"><p>Выбрать</p></button>
                            </div>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                    <form action="<?php echo e(route('client.send.order')); ?>" id="send_form" method="POST">
                        <?php echo csrf_field(); ?>
                    <div class="carrier__car-name">
                        <label class="label" for="index__name">
                            <div class="carrier__car-n">
                                <p>Как вас зовут </p><img src="/assets/svg/carrier/help.svg" alt="icons">
                            </div><img class="carrier__car-name_m" src="/assets/svg/carrier/user.svg" alt="icons">
                            <input type="text" name="name" required id="index__name" Placeholder="Ваше имя*" value="<?php echo e(Auth()->user()->name); ?>">
                        </label>
                    </div>
                    <div class="carrier__car-phone">
                        <label class="label" for="index__phone">
                            <div class="carrier__car-ph">
                                <p>Куда </p><img src="/assets/svg/carrier/help.svg" alt="icons">
                            </div><img class="carrier__car-phone_m" src="/assets/svg/carrier/phone.svg" alt="icons">
                            <input type="text" name="phone" id="index__phone" required Placeholder="Ваш телефон*" value="<?php echo e(Auth()->user()->phone); ?>">
                        </label>
                    </div>
                        <input type="hidden" value="<?php echo e(Auth()->user()->id); ?>" name="user_id">
                        <input type="hidden" id="waypoint_id" name="waypoint_id" value="">
                    <button class="carrier__car-trns" type="button" onclick="check_form()">
                        <p>Подать заявку</p><img src="/assets/svg/carrier/chevron-right.svg" alt="icons">
                    </button>
                    </form>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        function check_form(){
            let way_error = 0;
            let name_error = 0;
            let phone_error = 0;

            if($('#waypoint_id').val() == '') {
                $('#chose_transport').removeClass('display-n');
                way_error = 1;
            }else{
                $('#chose_transport').addClass('display-n');
                way_error = 0;
            }

            if($('#index__name').val() == ''){
                $('#name_error').removeClass('display-n');
                name_error = 1;
            }else{
                $('#name_error').addClass('display-n');
                name_error = 0;
            }

            if($('#index__phone').val() == ''){
                $('#phone_error').removeClass('display-n');
                name_error = 1;
            }else{
                $('#phone_error').addClass('display-n');
                name_error = 0;
            }

            if(way_error == 0 && name_error == 0 && phone_error == 0) {
                $('#send_form').submit();
            }
        }
        $('body').on('click', '.chose__car', function () {
            $('.chose__car').not($(this)).html('<p>Выбрать</p>');
            $(this).html('<p>Выбран</p>');
            $('#waypoint_id').val($(this).data('id'));
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\OpenServer\domains\logistic\resources\views/client/get.blade.php ENDPATH**/ ?>