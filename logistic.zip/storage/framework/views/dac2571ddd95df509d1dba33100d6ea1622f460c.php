<?php $__env->startSection('title', 'Заказы'); ?>
<?php $__env->startSection('content'); ?>
    <section class="carrier">
        <div class="containers">
            <div class="carrier__w">
                <?php echo $__env->make('client.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <ul class="carrier__info">
                    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="carrier__info-w">
                        <div class="carrier__info-icon"><img src="/assets/svg/carrier/car.svg" alt="icons"></div>
                        <div class="carrier__info-a">Транспорт в пути</div>
                        <div class="carrier__info-title">Номер: <?php echo e($order->get_waypoint->car_number); ?></div>
                        <div class="carrier__info-g">
                            <div class="carrier__info-i">
                                <div class="carrier__info-t">Машина в пути</div>
                                <div class="carrier__info-e">
                                    <h5>Дата оправления:</h5>
                                    <p><?php echo e($order->get_waypoint->departure_date); ?></p>
                                </div>
                                <div class="carrier__info-e">
                                    <h5>Время в пути:</h5>
                                    <p><?php echo e($order->get_waypoint->travel_time); ?></p>
                                </div>
                                <div class="carrier__info-e">
                                    <h5>Дата прибытия:</h5>
                                    <p><?php echo e($order->get_waypoint->arrival_date); ?></p>
                                </div>
                            </div>
                            <div class="carrier__info-i">
                                <div class="carrier__info-t">Данные по грузу</div>
                                <div class="carrier__info-e">
                                    <h5>Вес:</h5>
                                    <p><?php echo e($order->get_waypoint->weight); ?></p>
                                </div>
                                <div class="carrier__info-e">
                                    <h5>Объем:</h5>
                                    <p><?php echo e($order->get_waypoint->size); ?></p>
                                </div>
                                <div class="carrier__info-e">
                                    <h5>Кол-во упаковок:</h5>
                                    <p><?php echo e($order->get_waypoint->packages_qty); ?></p>
                                </div>
                            </div>
                            <div class="carrier__info-i">
                                <div class="carrier__info-t">Машина в пути</div>
                                <div class="carrier__info-e">
                                    <h5>Отправление:</h5>
                                    <p>Караганда</p>
                                </div>
                                <div class="carrier__info-e">
                                    <h5>Прибытие:</h5>
                                    <p>Усть-Каменогорск</p>
                                </div>
                                <div class="carrier__info-e">
                                    <h5>Расстояние:</h5>
                                    <p>758 км</p>
                                </div>
                                <div class="carrier__info-e">
                                    <h5>Пройдено:</h5>
                                    <p>158 км</p>
                                </div>
                            </div>
                        </div>
                    </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\OpenServer\domains\logistic\resources\views/client/orders.blade.php ENDPATH**/ ?>