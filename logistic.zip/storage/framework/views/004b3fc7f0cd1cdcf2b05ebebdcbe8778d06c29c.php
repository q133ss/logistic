
<?php $__env->startSection('title', 'Личный кабинет'); ?>
<?php $__env->startSection('content'); ?>
    <section class="carrier">
        <div class="containers">
            <div class="carrier__w">
                <?php echo $__env->make('client.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="carrier__search">
                    <form action="<?php echo e(route('client.get.car')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                    <div class="carrier__search-i">Поиск транспорта</div>
                    <div class="carrier__search-t">Подберем транспорт для вашего груза</div>
                    <div class="carrier__search-a">Помощь в организации сборных грузов</div>
                    <div class="carrier__search-b">
                        <div class="carrier__search-type">
                            <div class="carrier__search-h">
                                <p>Тип транспорта</p><img src="/assets/svg/index/help.svg" alt="icons">
                            </div>
                            <select class="c_select" id="track_i" name="type" style="display: none">
                                <option>Тип транспорта</option>
                                <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($type->id); ?>"><?php echo e($type->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="carrier__search-type"></div>
                        <div class="carrier__search-type">
                            <div class="carrier__search-h">
                                <p>Откуда везете груз</p><img src="/assets/svg/index/help.svg" alt="icons">
                            </div>
                            <select class="c_select" id="map_i" name="city1" style="display: none">
                                <option>Откуда везете</option>
                                <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($city->id); ?>"><?php echo e($city->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="carrier__search-type">
                            <div class="carrier__search-h">
                                <p>Выберите точку доставки</p><img src="/assets/svg/index/help.svg" alt="icons">
                            </div>
                            <select class="c_select" id="map_i" name="city2" style="display: none">
                                <option>Куда везете</option>
                                <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($city->id); ?>"><?php echo e($city->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div><button type="submit" class="carrier__search-rsl" href="#">
                        <p>Найти транспорт</p><img src="/assets/svg/carrier/chevron-right.svg" alt="icons"></button>
                    </form>
                </div>
            </div>
        </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\OpenServer\domains\logistic\resources\views/client/index.blade.php ENDPATH**/ ?>